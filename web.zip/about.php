
<?php 
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
       <h1> </h1>
  <center>
    <fieldset>
    
	<h1>About Us!</h1>
	
        
    

    <p>
        Real Estate . <br>
		Bashundhora, Block C,  House 165/a,  Dhaka. <br>
		PhoneNo:  01xxxxxxxx <br>
		Email:ruksanahayat182@gmail.com
</p>
    </fieldset>
	
	<a href="home.php">HOME </a> </br> 
	
	
	</center>
</body>
</html>





