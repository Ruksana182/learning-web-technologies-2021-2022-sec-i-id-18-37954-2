<?php

?>




<!DOCTYPE html>
<html>
<head>
<title>My Account</title>





</head>
<body>



<h2>My Account</h2>



<table>
<tr>
<th>Name</th>
<th>Password</th>
<th>Comfirm Password</th>
<th>Email</th>
<th>User Type</th>
</tr>
<tr>
<td>peyal</td>
<td>456</td>
<td>456</td>
<td>ruksanahayat182.@gamil.com</td>
<td>brokers</td>
</tr>
<tr>
<td>payel</td>
<td>123</td>
<td>123</td>
<td>nahida@gamil.com</td>
<td>brokers</td>
</tr>

</table>
<a href="home.php"> HOME</a>
</body>
</html>



